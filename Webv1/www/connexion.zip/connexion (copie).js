var xhr; 
var connect = document.getElementById("connect");
connect.addEventListener("click", submitForm);

function submitForm()
{ 
    try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
    catch (e) 
    {
        try {   xhr = new ActiveXObject('Microsoft.XMLHTTP'); }
        catch (e2) 
        {
           try {  xhr = new XMLHttpRequest();  }
           catch (e3) {  xhr = false;   }
         }
    }
   console.log("On set stateCHange");
   xhr.onreadystatechange  = stateChange;
   console.log("On va exe le script !");
   xhr.open("GET", "../htbin/login.py",  true); 
   console.log("On a exe le script !");
   xhr.send(null); 
} 

function stateChange()
{
	if(xhr.readyState  == 4)
    {
        if(xhr.status  == 200) 
            console.log(xhr.responseText);
        else
        {
        	console.log("Marche pas !");
        	console.log(xhr.status);
        }
            
    }
}
